<?php
$device_ip=$_SERVER['REMOTE_ADDR'];
echo $device_ip;

?>